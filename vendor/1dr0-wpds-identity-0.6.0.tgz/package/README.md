# WPDS Identity

`@1dr0/wpds-identity` is the canonical, dependency-free identity-image runtime
for the WPDS app family. It bundles deterministic Gravatar identicons for known
products and creates stable circular profile avatars from portable recipes.

```ts
import { generatedIdentityImage } from '@1dr0/wpds-identity';

const logo = generatedIdentityImage( 'mark', 'Snippet Manager' );
const avatar = generatedIdentityImage( 'avatar', 'Daniel Kam', 'monogram' );
```

Known family products resolve through `PRODUCT_MARK_CATALOGUE`. Each app uses the
SHA-256 hash of `<product-id>@wpds.invalid` to request Gravatar's forced
`identicon` fallback at design time. The resulting PNG and its source hash are
bundled into the package, so released apps do not depend on Gravatar at runtime.
Aliases let repository ids and product labels resolve to the same mark. The
unknown-product SVG fallback is for prototypes only; add a catalogue entry and
regenerate the assets before release.

Use a stable, non-secret app id, title, profile id, or display name as the seed.
Account images and authorised uploads take precedence for profile avatars.
Gravatar helpers hash a normalised email and store only the hash or an embedded
result. Wapuu Studio and image MCPs remain optional asset providers whose result
enters through the ordinary image field.

Run `npm run generate:identicons` only when the product catalogue changes, then
review and commit the generated asset manifest. The generator fails when the
service returns a non-PNG or duplicates an existing product asset.

Import `@1dr0/wpds-identity/styles.css` and apply `wpds-identity-image is-mark`
or `wpds-identity-image is-avatar` for the family geometry.

The package also owns the family footer's profile navigation and profile page.
They are framework-neutral DOM primitives, so React and dependency-free apps use
the same full-width sidebar row, page editor, validation, avatar generation,
upload limit, and local persistence model:

```ts
import { mountEditableProfile, mountEditableProfilePage } from '@1dr0/wpds-identity';

const profile = mountEditableProfile( footerNode, {
  appId: 'snippet-manager',
  profile: { displayName: 'Local user', secondary: 'Private to this app' },
  onOpen: () => navigate( 'profile' ),
} );

const profilePage = mountEditableProfilePage( pageNode, {
  appId: 'snippet-manager',
  profile: { displayName: 'Local user', secondary: 'Private to this app' },
  onCancel: () => navigate( 'overview' ),
  onSaved: () => navigate( 'overview' ),
} );

profile.destroy();
profilePage.destroy();
```

Use `persistence: 'external'` with `onSave` when the host owns an authenticated
account. Use `onOpen` to route the shared trigger to the app's dedicated profile
page. Profile settings never use a modal, dialog, drawer, or popover. Login
identifiers remain read-only; the editable display identity is a separate field.

Non-module hosts load `dist/browser.js`, which exposes the same functions as
`window.WPDSIdentity`. The IIFE and ES module are generated from the same source.
