# WPDS Identity

`@1dr0/wpds-identity` is the canonical, dependency-free identity-image runtime
for the WPDS app family. It creates stable rounded-square app marks and circular
profile avatars from compact portable recipes.

```ts
import { generatedIdentityImage } from '@1dr0/wpds-identity';

const logo = generatedIdentityImage( 'mark', 'Snippet Manager', 'tiles' );
const avatar = generatedIdentityImage( 'avatar', 'Daniel Kam', 'monogram' );
```

Use a stable, non-secret app id, title, profile id, or display name as the seed.
Account images and authorised uploads take precedence. Gravatar helpers hash a
normalised email and store only the hash or recipe. Wapuu Studio and image MCPs
remain optional asset providers whose result enters through the ordinary image
field.

Import `@1dr0/wpds-identity/styles.css` and apply `wpds-identity-image is-mark`
or `wpds-identity-image is-avatar` for the family geometry.

Non-module hosts load `dist/browser.js`, which exposes the same functions as
`window.WPDSIdentity`. The IIFE and ES module are generated from the same source.
