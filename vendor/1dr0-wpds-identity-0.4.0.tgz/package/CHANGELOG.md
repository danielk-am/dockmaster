# Changelog

## 0.4.0

- Replace semantic product silhouettes with distinct Gravatar identicons generated from reserved product seeds.
- Bundle the generated PNGs and retain their seed, source URL, and SHA-256 provenance for offline releases.
- Preserve the `0.3` primary-colour compatibility API for existing consumers.

## 0.3.0

- Add app-primary palette helpers and browser token discovery.

## 0.2.0

- Add the shared product catalogue and deterministic identity recipes.
