# `@1dr0/ai-chat`

A reusable chat panel built from WordPress Design System primitives. The package
separates conversation UI, model transport, agent orchestration, app context,
and app-owned tools.

The WordPress Design System does not currently provide a chat or conversation
component. `AiChat` composes WPDS `Button`, `Card`, `EmptyState`,
`SelectControl`, `Stack`, `Text`, `TextareaControl`, `FormFileUpload`,
`DropZone`, `Notice`, and `Spinner` primitives. Its stylesheet is limited to
structural layout and semantic `--wpds-*` tokens.

## Install

The package is an npm workspace in UI Playground. Build and pack it for an app
outside this repository:

```bash
npm run build:ai-chat
npm pack --workspace @1dr0/ai-chat
# In the consuming app:
npm install /path/to/1dr0-ai-chat-0.6.5.tgz
```

After the package is published to an internal registry, consumers can instead
install it by name with `npm install @1dr0/ai-chat`.

Import the component and its stylesheet:

```tsx
import { AiChat } from "@1dr0/ai-chat";
import "@1dr0/ai-chat/styles.css";
```

`react`, `react-dom`, `@wordpress/components`, `@wordpress/icons`,
`@wordpress/theme`, and `@wordpress/ui` are peer dependencies.

This workspace package is the canonical source. App repositories consume its
built package; they must not fork the component, resize handle or transport
contract into app-local copies.

## Default: app-managed access

Use `createAppManagedTransport` for an owned app. It asks one same-origin
access endpoint to resolve the authenticated user on the server:

```tsx
import { AiChat, createAppManagedTransport } from "@1dr0/ai-chat";

const transport = createAppManagedTransport({
  accessEndpoint: "/api/ai/access",
});

<AiChat appId="my-app" transport={transport} resizable />;
```

The endpoint returns one of these server-authoritative results:

```json
{ "mode": "owner-terminal", "endpoint": "/api/ai/owner/chat" }
{ "mode": "member-token", "endpoint": "/api/ai/member/chat" }
{ "mode": "unavailable", "message": "Ask AI is not configured." }
```

The browser never sends an owner flag and cannot choose the returned route.
Both the access endpoint and returned chat endpoint must be same-origin.

- `owner-terminal` calls the authenticated owner route with cookies. The host,
  not this browser package, is responsible for a constrained terminal broker.
- `member-token` prompts for a per-user API token, keeps it only in the
  transport closure, and sends it to the resolved route as a bearer.
- `unavailable`, malformed responses, cross-origin routes and access failures
  fail closed.

This package deliberately does not expose a raw CLI or terminal adapter. A host
must authenticate the request, resolve the principal, constrain any owner
broker, validate all model output, and authorise every app tool.

## Alternative: a server-managed bridge

Keep provider and bridge credentials in the app server. The browser calls a
same-origin route:

```tsx
import { AiChat, createA8CBridgeOptions } from "@1dr0/ai-chat";
import "@1dr0/ai-chat/styles.css";

const bridges = createA8CBridgeOptions([
  {
    provider: "claude",
    endpoint: "/api/ai/v1/bridges/claude/chat/completions",
  },
  {
    provider: "gemini",
    endpoint: "/api/ai/v1/bridges/gemini/chat/completions",
  },
  {
    provider: "chatgpt",
    endpoint: "/api/ai/v1/bridges/chatgpt/chat/completions",
  },
]);

export function AppAssistant() {
  return (
    <AiChat
      appId="my-app"
      bridges={bridges}
      defaultBridge="gemini-a8c"
      instructions="Answer only about this app's publishing workflow."
      appearance="system"
      allowAttachments
      persistConversations
      expandable
      resizable
    />
  );
}
```

Each provider-specific route relays to its matching A8C AI Bridge. The selector
uses the exact bridge names and states the underlying API provider:

- `Claude-a8c` uses Anthropic Claude and is text-only.
- `Gemini-a8c` uses Google Gemini and accepts image attachments.
- `ChatGPT-a8c` uses OpenAI and accepts image attachments.

The browser does not show a key field or send a bridge bearer. The app server
owns each provider's credential and the `X-A8C-Client-ID` header. Switching
bridges starts a new conversation after confirmation so provider-incompatible
messages and attachments are not reused.

## Direct API keys

Direct Anthropic and OpenAI-compatible adapters are available for local tools
and browser-only demos:

```tsx
const transport = createAnthropicTransport({
  model: "claude-sonnet-4-6",
  dangerouslyAllowBrowser: true,
  models: [{ id: "claude-sonnet-4-6", label: "Claude Sonnet 4.6" }],
});

<AiChat appId="local-demo" transport={transport} />;
```

When the adapter has no key, `AiChat` shows a key form. The adapter keeps that
key only in a closure in page memory. It is never written to local storage,
messages, app data, or exports.

The form names the credential explicitly as an **Anthropic API key**. A custom
OpenAI-compatible direct adapter should set `providerLabel` and `apiKeyLabel`
so the UI can name its provider and credential just as clearly.

`dangerouslyAllowBrowser: true` adds Anthropic's required direct-browser
request header. The explicit name is intentional: browser code cannot keep a
provider key secret.

A browser key is still visible to the page and browser extensions. Use a
server-managed bridge for production or shared environments.

## Normalised JSON bridge

Use `createJsonBridgeTransport` when the app server accepts this package's
normalised contract instead of OpenAI Chat Completions:

```tsx
const transport = createJsonBridgeTransport({
  endpoint: "/api/ai/chat",
  configEndpoint: "/api/ai/config",
  config: {
    provider: "internal-bridge",
    hasApiKey: true,
    apiKeySource: "server",
    apiKeyEditable: false,
  },
});
```

The chat route receives `ChatCompleteRequest` and returns `AssistantTurn` or
`{ turn: AssistantTurn }`. Bridge routes must be same-origin. The adapter sends
cookies with `credentials: 'same-origin'`.

`createWordPressApiFetchTransport` is also available for a WordPress REST host.
It accepts an injected `apiFetch` function, so this package does not depend on
`@wordpress/api-fetch`.

### Existing a8c bridges

Server applications can import `createOpenAICompatibleRelay` from
`@1dr0/ai-chat/server`. The relay keeps the bridge bearer on the server,
requires an app-owned model and output-token allowlist, caps request and
response size, applies an upstream timeout, preserves streaming responses, and
sends the bridge's general-client `X-A8C-Client-ID` identity. A Node host must
pipe a returned `ReadableStream` to its HTTP response rather than passing it to
`res.send()`.

The browser still uses `createOpenAICompatibleTransport` with
`apiKeyMode: 'server'` against the app's same-origin route.

Prefer `createA8CBridgeOptions` for A8C apps that expose the three selectable
bridges. `createA8CBridgeTransport` remains available for a deliberately fixed
single bridge. Both add the provider name, curated model defaults, and
image-capability metadata. The generic OpenAI-compatible transport remains
available for non-A8C providers.

## Streaming responses

`AiChat` renders assistant text as JSON events arrive. The Anthropic and
OpenAI-compatible adapters expose `transport.stream()`, while
`runAgentTurn()` falls back to `transport.complete()` for transports that do
not support streaming.

OpenAI-compatible routes request `stream: true` and accept either standard SSE
with JSON in each `data:` field or newline-delimited JSON. The shared server
relay passes those streams through without buffering and retains its byte,
timeout, model, and credential boundaries. Streamed tool-call fragments are
assembled before the app-owned tool executes.

The browser request remains same-origin. Aborting or pressing Stop cancels the
active stream and is forwarded to the provider by a correctly wired app relay.

## Image attachments

Set `allowAttachments` on the component. Users can choose, paste, or drag PNG,
JPEG, GIF, and WebP images. The default limit is three images and 2 MiB total,
which stays below the relay's 4 MiB JSON request cap after base64 encoding.

When the app requests attachments, the `Attach` action remains visible. It is
enabled when both the transport and selected model support images and disabled
with a provider-specific explanation when they do not. Claude-a8c is text-only;
Gemini-a8c and ChatGPT-a8c accept images. A model can opt out with
`supportsImages: false`.

## Conversation history

Set `persistConversations` to keep app-scoped sessions in the current browser:

```tsx
<AiChat
  appId="notes"
  transport={transport}
  persistConversations
  maxSavedConversations={20}
/>
```

History uses the required `appId` namespace:

```text
@1dr0/ai-chat:<encoded-app-id>:conversations
```

New conversation archives the current transcript instead of discarding it.
History is local to that browser and app, and can be opened, resumed, deleted,
or cleared from the panel. The package stores text only. Image binaries, image
URLs, tool calls, and tool results are removed before persistence.

History is opt-in because transcript text can still be sensitive. Leave
`persistConversations` unset when the host already owns encrypted or
server-synchronised session storage.

## Panel sizing and composer actions

Set `expandable` for a four-corner expand or restore action. Set `resizable` for
a left-edge horizontal drag handle:

```tsx
<AiChat
  appId="notes"
  transport={transport}
  expandable
  resizable
  defaultWidth={400}
  minWidth={320}
  maxWidth={960}
  onWidthChange={(width) => saveHostLayout(width)}
/>
```

The resize separator supports Arrow Left and Arrow Right for keyboard users.
When package preferences are enabled, the chosen width is saved for that
`appId`.

`AiChatResizeHandle` exports the same short vertical handle for durable left and
right panels. Its 16 pixel pointer target straddles the pane boundary by 8
pixels on each side, while the 4 by 32 pixel rounded mark stays inside its
owning pane and appears on hover, keyboard focus, or drag. The component also
preserves separator semantics and mirrored keyboard stepping.

`PopoverSelect` is the shared WPDS popup selector for compact app controls. Use
it instead of a native `<select>` when a family app needs a dropdown, so focus,
Escape, outside-click dismissal, disabled options, labels and overlay placement
remain consistent. Set `disabled` when the whole selector is unavailable; the
trigger then remains labelled, disabled, closed, and unable to change value.
Dropdown-only modules may import it from `@1dr0/ai-chat/popover-select` so
Node-side form tests do not load the full chat and Markdown runtime.

The composer keeps `Attach | app actions | Send` on one row and the keyboard
hint on the row below. Use `composerActions` for one or two app-owned controls,
such as a prompt picker or context selector:

```tsx
<AiChat
  appId="notes"
  transport={transport}
  composerActions={
    <Button size="compact" onClick={openPromptPicker}>
      Prompts
    </Button>
  }
/>
```

Keep destructive actions and dense menus out of this slot. App tools remain
model-callable capabilities passed through `tools`. `composerActions` is also a
slot name, so the same row is reachable as a render function and from the
registry; see [Extending the panel](#extending-the-panel-slots).

## Message rendering

User and assistant messages use full-width WPDS card surfaces with distinct
semantic brand and neutral colors. Assistant responses render Markdown,
GitHub-flavored tables and task lists, and safe inline HTML. The renderer
sanitizes HTML before it reaches the DOM and omits model-supplied inline images;
use the attachment UI for image content. User-authored messages remain plain
text.

## Extending the panel: slots

The panel is closed by default and opened at fifteen named slots. A slot takes
a render function and puts whatever it returns at one exact position. This is
how an app adds a per-message control, such as an audio play button under an
assistant answer, without forking the component.

Around each message:

| Slot | Position |
| --- | --- |
| `messageAbove` | outside the card, above the role label |
| `bubbleTop` | inside the card, before the body |
| `bubbleBottom` | inside the card, after the body |
| `messageBelow` | outside the card, under the bubble |

Around the thread, inside the scrolling transcript: `threadTop`,
`threadBottom`.

On the panel chrome: `panelBackground`, `headerTop`, `headerActions`,
`headerBottom`, `composerTop`, `composerActions`, `composerBottom`,
`footerTop`, `footerBottom`.

### Per panel, with the `slots` prop

```tsx
<AiChat
  appId="notes"
  transport={transport}
  slots={{
    messageBelow: ({ role, text, index }) =>
      role === "assistant" ? <PlayButton key={index} text={text} /> : null,
    headerActions: () => <VoiceToggle />,
  }}
/>
```

A message renderer receives the message, its `role`, the rendered `text`, the
unfiltered `rawText`, the raw `content` blocks including `tool_use` and
`tool_result`, the `index`, a stable `key`, `isLast`, and `isStreaming`. A
thread or panel renderer receives the `appId`, `title`, resolved `appearance`,
`messages`, `isStreaming`, `isExpanded`, and `isReady`.

### Across panels, with the registry

`addAiChatSlot` registers a renderer without owning the mount site, the way a
WordPress hook does. It returns a function that removes the registration.

```tsx
import { addAiChatSlot, addAiChatFilter } from "@1dr0/ai-chat";

const remove = addAiChatSlot(
  "messageBelow",
  ({ role, text }) =>
    role === "assistant" ? <PlayButton text={text} /> : null,
  { appId: "notes", namespace: "notes/audio", priority: 10 },
);
```

- `appId` scopes the renderer to one panel. Omit it to reach every panel.
- `priority` orders renderers, lower first, defaulting to 10. A renderer passed
  through the `slots` prop also sits at 10 and wins a tie.
- `namespace` makes the registration replaceable: registering the same
  namespace again on the same slot and `appId` replaces it rather than stacking
  a duplicate. `removeAiChatSlot(slot, namespace, appId)` removes it by name.

Registering or removing re-renders every mounted panel, so an extension that
loads late still appears. `clearAiChatHooks()` drops everything, which is what
tests and hot reloads want.

A renderer that throws is logged to the console and its output dropped. The
rest of the panel keeps rendering.

### Filters

`messageText` rewrites a bubble's text before the Markdown renderer sees it.
The slot context keeps the original as `rawText`, so a marker can drive a
control and still leave the reader's copy clean.

```tsx
addAiChatFilter("messageText", (text) => text.replace(/\[\[speak]]/g, "").trim(), {
  namespace: "notes/audio",
});

addAiChatSlot("messageBelow", ({ role, rawText }) =>
  role === "assistant" && rawText.includes("[[speak]]") ? (
    <PlayButton text={rawText} />
  ) : null,
);
```

A filter that throws, or returns anything other than a string, is skipped and
the previous value carries forward.

The registry is global to the page, the same trust boundary as a WordPress
hook. Only register from code the host controls; slot output is host React,
never model output.

## Customising the design

Two props sit beside the slots. Both default to exactly what the panel already
renders, so an omitted key changes nothing.

`tokens` sets design values as CSS custom properties on the panel root:

```tsx
<AiChat
  appId="notes"
  transport={transport}
  tokens={{
    radius: "12px",
    bubbleRadius: "16px",
    userBubbleBg: "#1d4ed8",
    userBubbleFg: "#ffffff",
    transcriptGap: "20px",
    headerBg: "transparent",
    footerBg: "transparent",
    "--wpds-color-bg-surface-brand": "#1d4ed8",
  }}
/>
```

Named keys: `gutter`, `radius`, `surfaceBg`, `surfaceFg`, `borderColor`,
`headerBg`, `footerBg`, `transcriptGap`, `transcriptPadding`, `bubbleRadius`,
`bubblePadding`, `userBubbleBg`, `userBubbleFg`, `assistantBubbleBg`,
`assistantBubbleFg`, `labelColor`, `composerRadius`, `fontFamily`, `fontSize`,
and `lineHeight`. Any `--` key passes through untouched, which is how a host
reaches a WPDS token this table does not name.

Transparent surface tokens are what make `panelBackground` useful: the slot
paints behind the panel, and the header and footer stop covering it.

`classNames` attaches host classes to named structural parts, alongside the
component's own class rather than replacing it:

```tsx
<AiChat
  appId="notes"
  transport={transport}
  classNames={{ root: "brand-panel", messageCard: "brand-bubble" }}
/>
```

Parts: `root`, `header`, `headerTop`, `headerActions`, `title`, `transcript`,
`message`, `userMessage`, `assistantMessage`, `messageLabel`, `messageCard`,
`footer`, `composer`, `input`, and `composerActions`.

## App context and tools

Apps own their context and tool allowlist:

```tsx
const tools: ChatTool[] = [
  {
    name: "create_note",
    description: "Create a note in the current app.",
    inputSchema: {
      type: "object",
      properties: { title: { type: "string" } },
      required: ["title"],
    },
    execute: async (input) => createNote(input),
  },
];

<AiChat
  appId="notes"
  transport={transport}
  instructions="Help with the notes app."
  getContext={() => JSON.stringify(getCurrentNote())}
  tools={tools}
  persistConversations
  expandable
  resizable
/>;
```

The bounded agent runner sends only the supplied tool definitions, executes
only those tool objects, ignores replayed tool-use IDs, returns unknown-tool
calls as errors, propagates abort, and fails explicitly when it reaches
`maxSteps`. The host remains responsible for validating every tool input and
authorising every mutation.

## Appearance

`appearance` accepts `system`, `light`, or `dark`. `system` follows
`prefers-color-scheme` live. The resolved value is scoped through the WPDS
theme provider and stamped on the component with `data-ai-chat-theme`.
Settings replace the transcript and composer inside the same panel, fill its
remaining height, and use the same WPDS theme. Give the `AiChat` host a
definite height when it should fill a sidebar or drawer.

Use `contextSummary` for a short, visible app-status line. Keep detailed or
sensitive model context in `getContext`, which is not rendered by the package.

When the host fixes output limits at its trusted server boundary, return
`maxOutputTokensEditable: false` from `transport.getConfig()`. The settings
surface then omits the response-length control instead of presenting a
selection that the server will ignore.

## App-scoped custom instructions

`appId` is required. Uncontrolled custom instructions, model, and response
length preferences are saved under:

```text
@1dr0/ai-chat:<encoded-app-id>:preferences
```

This prevents settings from bleeding between apps. For host-owned state, use
the controlled props:

```tsx
<AiChat
  appId="support-console"
  transport={transport}
  customInstructions={instructions}
  onCustomInstructionsChange={setInstructions}
/>
```

Set `persistPreferences={ false }` to disable package-owned persistence.
Fixed `instructions` and current `getContext()` output are never persisted by
the package. When persistence is disabled, the settings panel labels custom
instructions as applying to the current conversation only.

## Main API

- `AiChat`: WPDS-based component, transcript, attachments, settings, key form,
  abort, app-scoped history, expand or restore, horizontal resizing, visible
  context summary, composer action slot, and manual compaction.
- `AiChatResizeHandle`: the shared accessible short vertical resize primitive.
- `addAiChatSlot`, `removeAiChatSlot`, `addAiChatFilter`, `removeAiChatFilter`,
  and `clearAiChatHooks`: the page-wide slot and filter registry.
- `tokensToStyle` and the `AiChatSlots`, `AiChatTokens`, `AiChatClassNames`,
  `AiChatMessageSlotContext`, and `AiChatPanelSlotContext` types.
- `PopoverSelect`: the shared WPDS button-and-popover selector.
- `createAppManagedTransport`: server-resolved owner terminal or member-token
  access with same-origin enforcement and fail-closed defaults.
- `runAgentTurn`: provider-neutral bounded tool loop.
- `createAnthropicTransport`: direct Anthropic Messages adapter.
- `createA8CBridgeOptions`: selectable Claude-a8c, Gemini-a8c, and ChatGPT-a8c
  bridge definitions.
- `createA8CBridgeTransport`: fixed single A8C bridge adapter.
- `createOpenAICompatibleTransport`: direct provider or server bridge adapter.
- `createJsonBridgeTransport`: same-origin normalised bridge adapter.
- `createWordPressApiFetchTransport`: injected WordPress REST adapter.
- `ChatTransport`, `ChatMessage`, `ChatTool`, and related public types.
